<?php
	$pdo = null;
try
{
    $pdo = new PDO('mysql:host=localhost;dbname=m1dfsw', 'root', '');

}
catch (Exception $e)
{
    die('Erreur : ' . $e->getMessage());
}
?>